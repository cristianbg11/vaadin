class UrlMappings {

	static mappings = {
	}
}